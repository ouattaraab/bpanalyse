# Active Context

## État actuel
Kit de démarrage déposé. Aucune ligne de code applicatif écrite. Interfaces IA et config de routage présentes ; squelette Laravel pas encore initialisé.

## Prochaine action
Suivre BOOTSTRAP.md :
1. Étape 0 — charger le contexte (CLAUDE.md, PRD, memory-bank) et synthétiser.
2. Étape 1 — plan d'implémentation Phase 0 + Phase 1, mettre à jour ce fichier et progress.md.
3. Étape 2 — scaffolding Laravel sans écraser les fichiers existants.

## Décisions ouvertes
- Tester le function calling de Groq sur de vrais tableaux avant de lui confier l'outil de calcul (sinon router vers Claude).
- Front React + Reveal.js vs Flutter Web : trancher avant la Phase 2.

## Rappels
- Ne PAS implémenter l'Epic 7 (DocumentProfile) au MVP.
- Chiffres déterministes, jamais le LLM.
