# Progress

## Fait
- Cadrage produit, PRD BMAD (8 sections, 7 epics, ~32 user stories).
- Diagramme d'architecture.
- Décisions techniques : routage LLM hybride Groq/Claude ; abstraction DocumentProfile cadrée pour plus tard.
- Kit de démarrage : CLAUDE.md, docs, interfaces IA, config/ai.php, memory-bank.

## En cours
- Rien (implémentation pas démarrée).

## À faire (par phase)
- [ ] Phase 0 — Epic 1 : ingestion (1.1→1.5)
- [ ] Phase 1 — Epic 2.1-2.2 chat RAG + Epic 1.5 outil de calcul
- [ ] Phase 2 — Epic 3 présentation express
- [ ] Phase 3 — Epic 4 débat du board
- [ ] Phase 4 — Epics 2.3, 5, 6 voix/compte rendu/gouvernance
- [ ] Phase 5 (post-MVP) — Epic 7 DocumentProfile

## Problèmes connus
- Fiabilité function calling Groq à valider.
